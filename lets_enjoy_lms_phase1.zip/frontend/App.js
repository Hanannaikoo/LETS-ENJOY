
import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';

const socket = io('http://localhost:5000');

function App() {
  const [connectedUsers, setConnectedUsers] = useState([]);
  const roomId = 'classroom123';
  const userId = 'user' + Math.floor(Math.random() * 1000);

  useEffect(() => {
    socket.emit('join-room', roomId, userId);

    socket.on('user-connected', userId => {
      setConnectedUsers(prev => [...prev, userId]);
    });

    socket.on('user-disconnected', userId => {
      setConnectedUsers(prev => prev.filter(id => id !== userId));
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div>
      <h1>LETS ENJOY LMS Live Classroom</h1>
      <p>You are: {userId}</p>
      <p>Room: {roomId}</p>
      <h3>Connected Users:</h3>
      <ul>
        {connectedUsers.map(id => <li key={id}>{id}</li>)}
      </ul>
    </div>
  );
}

export default App;
